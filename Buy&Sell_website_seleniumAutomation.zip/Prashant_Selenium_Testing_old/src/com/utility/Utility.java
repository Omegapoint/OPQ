package com.utility;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.io.InputStream;
import java.math.BigDecimal;
import java.util.Enumeration;
import java.util.Properties;

public class Utility {
	
	
	public static BigDecimal getProductAmount(String product_name) {
		String sKey = "";
		int sValue = 0;
		try {
			File file = new File("/Users/prashantmundepi/eclipse-workspace/Prashant_Selenium_Testing/src/com/utility/Pricelist.properties");
			
			BufferedReader in = new BufferedReader(new FileReader(file));
			
			int line = 0;
			for (String x = in.readLine(); x != null; x = in.readLine()) {
				
				if (line == 0 || line == 1) {
					line++;
					continue;
				}
				
				
				String [] tokens = x.split("\\=");
				int tkn = 0;
				for (String token : tokens) {
					if (tkn == 0) {
						sKey= token;
					}
					if (tkn == 1) {
						sValue = Integer.parseInt(token);
					}
					tkn++;
				}
				
				if(sKey.equals(product_name)) {
					break;
				}
				
				line++;
			}
			
			
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		} catch(Exception e) {
			e.printStackTrace();
		}
		finally {
			return BigDecimal.valueOf(sValue);
		}
	}
	
}