package TEST_NG;

import org.testng.annotations.Test;
import org.testng.AssertJUnit;
import static org.testng.Assert.assertEquals;
import static org.testng.Assert.assertNotEquals;

import java.math.BigDecimal;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.testng.annotations.*;

import com.utility.Utility;

public class TestNG_Tests {
	
	WebDriver driver;
	BigDecimal TotalAmount = new BigDecimal("0");
	BigDecimal VAT_afterSell = new BigDecimal("0");
	BigDecimal Total_afterSell = new BigDecimal("0");
	BigDecimal Total_beforeSell = new BigDecimal("0");
	BigDecimal priceBanana = new BigDecimal("0");
	BigDecimal priceApple = new BigDecimal("0");
	int i = 0;
	
	final static String PRODUCT_NAME_BANANA = "Banana";
	final static String PRODUCT_NAME_APPLE = "Apple";
	final static String PRODUCT_NAME_TV = "TV";
	
	String product_name;
	
  @BeforeMethod
  public void invokeBrowser() {								//Invoking browser before every (buy and sell) test
		
		try {
			System.setProperty("webdriver.chrome.driver", "/usr/local/bin/chromedriver");
			driver = new ChromeDriver();
			driver.manage().deleteAllCookies();
			driver.manage().window().maximize();
			driver.manage().timeouts().pageLoadTimeout(30, TimeUnit.SECONDS);
			driver.get("http://hoff.is/store/index.html");
			Thread.sleep(2000);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
  
  public void buyProduct(String product, int key) {				//generic function for Buying a product
	  try {
		  driver.findElement(By.id("buyAmount")).clear();
		  Select products = new Select(driver.findElement(By.className("form-control")));
		    products.selectByVisibleText(product);
			Thread.sleep(2000);
			driver.findElement(By.id("buyAmount")).sendKeys(""+key+"");
			driver.findElement(By.className("btn-primary")).click();
			Thread.sleep(2000);
	} catch (InterruptedException e) {
		e.printStackTrace();
	}
	  
  }
  
  public void sellProduct(){										//generic function for selling all the products in a test
	  
	  
				for(int i=0; i< 20 ;i++){
					
						try {
							if(!driver.findElements(By.xpath("/html/body/div[@class='container']/table[@class='table table-striped'][2]/tbody[@id='bought']/tr[@id="+i+"]/th[4]/button")).isEmpty())	
							{	
								Thread.sleep(2000);
							   driver.findElement(By.xpath("/html/body/div[@class='container']/table[@class='table table-striped'][2]/tbody[@id='bought']/tr[@id="+i+"]/th[4]/button")).click(); 
							}
							
							else
							{
							System.out.println("All products are sold out");
							return;
							}
						} catch (Exception e) {					//catch for "for" block
							e.printStackTrace();
						}	
						
				} // for loop closed
				  
				
			} // sellproduct generic function closed
    				 
 
 @Test(priority=0)
 public void BuySell_OneProduct() {                try {																//tested for 1 product, 2 quantity buy and sell
		 
	
			    Select products = new Select(driver.findElement(By.className("form-control")));
				buyProduct(PRODUCT_NAME_BANANA,2);																		// buy function calling 
				String product_name = null;
				product_name = products.getFirstSelectedOption().getText().toString();
				priceBanana = Utility.getProductAmount(PRODUCT_NAME_BANANA);
				priceBanana = priceBanana.multiply(new BigDecimal(driver.findElement(By.id("buyAmount")).getAttribute("value")));
				TotalAmount = TotalAmount.add(priceBanana);
				System.out.println("Product selected = " + product_name);
				System.out.println("Amount selected = " + driver.findElement(By.id("buyAmount")).getAttribute("value"));
				System.out.println("Message is: = " + driver.findElement(By.id("message")).getText());
				System.out.println("Total amount = " +TotalAmount);
				assertEquals(product_name, "Banana");															////assertions check for 1 product, 2 quantity buy and sell
				assertEquals(driver.findElement(By.id("buyAmount")).getAttribute("value"), "2");
				assertEquals(driver.findElement(By.id("message")).getText(), "You bought 2 x Banana for a total of 46");
				priceBanana = BigDecimal.ZERO;
				TotalAmount = BigDecimal.ZERO;
				
				sellProduct();																							//selling function calling
				VAT_afterSell = new BigDecimal(driver.findElement(By.id("totalVAT")).getText());
				Total_afterSell = new BigDecimal(driver.findElement(By.id("totalPrice")).getText());
				System.out.println("The sold product is: Banana");
				System.out.println("VAT is:" +VAT_afterSell);
				System.out.println("Total is:" +Total_afterSell);
				assertEquals(VAT_afterSell, new BigDecimal("0"));
				assertEquals(Total_afterSell, new BigDecimal("0"));
				VAT_afterSell = BigDecimal.ZERO;
				Total_afterSell = BigDecimal.ZERO;
				Thread.sleep(3000);
} catch (InterruptedException e) {
	e.printStackTrace();
}
				
}
 
 
 @Test(priority=1)
 public void BuySell_TwoProducts_() {                try {
	//tested for 2 product, 2 quantity buy and sell
		 
			    Select products = new Select(driver.findElement(By.className("form-control")));
				buyProduct(PRODUCT_NAME_BANANA,2);							// buy function calling, buying first product 
				String product_name = null;
				product_name = products.getFirstSelectedOption().getText().toString();
				priceBanana = Utility.getProductAmount(PRODUCT_NAME_BANANA);
				priceBanana = priceBanana.multiply(new BigDecimal(driver.findElement(By.id("buyAmount")).getAttribute("value")));
				TotalAmount = TotalAmount.add(priceBanana);
				System.out.println("Product selected = " + product_name);
				System.out.println("Amount selected = " + driver.findElement(By.id("buyAmount")).getAttribute("value"));
				System.out.println("Message is: = " + driver.findElement(By.id("message")).getText());
				assertEquals(product_name, "Banana");
				assertEquals(driver.findElement(By.id("buyAmount")).getAttribute("value"), "2");
				assertEquals(driver.findElement(By.id("message")).getText(), "You bought 2 x Banana for a total of 46");
				
				buyProduct(PRODUCT_NAME_APPLE,2);							// buy function calling, buying second product  
				product_name = null;
				product_name = products.getFirstSelectedOption().getText().toString();
				priceApple = Utility.getProductAmount(PRODUCT_NAME_APPLE);
				priceApple = priceApple.multiply(new BigDecimal(driver.findElement(By.id("buyAmount")).getAttribute("value")));
				TotalAmount = TotalAmount.add(priceApple);
				System.out.println("Product selected = " + product_name);
				System.out.println("Amount selected = " + driver.findElement(By.id("buyAmount")).getAttribute("value"));
				System.out.println("Message is: = " + driver.findElement(By.id("message")).getText());
				System.out.println("Total amount = " +TotalAmount);
				assertEquals(product_name, "Apple");
				assertEquals(driver.findElement(By.id("buyAmount")).getAttribute("value"), "2");
				assertEquals(driver.findElement(By.id("message")).getText(), "You bought 2 x Apple for a total of 30");
				TotalAmount = BigDecimal.ZERO;
				priceBanana = BigDecimal.ZERO;
				priceApple = BigDecimal.ZERO;
																		////assertions check for 2 different product, 2 quantity buy and sell		
				sellProduct();												//selling function calling
				VAT_afterSell = new BigDecimal(driver.findElement(By.id("totalVAT")).getText());
				Total_afterSell = new BigDecimal(driver.findElement(By.id("totalPrice")).getText());
				System.out.println("VAT is:" +VAT_afterSell);
				System.out.println("Total is:" +Total_afterSell);
				assertEquals(VAT_afterSell, new BigDecimal("0"));
				assertEquals(Total_afterSell, new BigDecimal("0"));
				VAT_afterSell = BigDecimal.ZERO;
				Total_afterSell = BigDecimal.ZERO;
				Thread.sleep(3000);
} catch (InterruptedException e) {
	e.printStackTrace();
}
			
}
 

 
 
 @Test(priority=2)										//Negative test case with negative quantity amount
 public void BuyProduct_NegativeQuantity() {              
		
		try {
			Select products = new Select(driver.findElement(By.className("form-control")));
			buyProduct(PRODUCT_NAME_BANANA,-1);							// buy function calling 	
			product_name = null;
			product_name = products.getFirstSelectedOption().getText().toString();
			System.out.println("Product selected = " + product_name);
			System.out.println("Amount selected = " + driver.findElement(By.id("buyAmount")).getAttribute("value"));
			System.out.println("Message is: = " + driver.findElement(By.id("message")).getText());
			assertEquals(product_name, "Banana");
			assertEquals(driver.findElement(By.id("buyAmount")).getAttribute("value"), "-1");
			assertEquals(driver.findElement(By.id("message")).getText(), "Enter a amount higher than 0.");	
			Thread.sleep(1000);
		} catch (Exception e) {
			e.printStackTrace();
		}
		
 }
 
 
 
 @Test(priority=3)																									//Negative test case with zero quantity amount
 public void BuyProduct_ZeroQuantity() {              
		
		try {
			Select products = new Select(driver.findElement(By.className("form-control")));
			buyProduct(PRODUCT_NAME_BANANA,0);																		// buy function calling 	
			product_name = null;
			product_name = products.getFirstSelectedOption().getText().toString();
			System.out.println("Product selected = " + product_name);
			System.out.println("Amount selected = " + driver.findElement(By.id("buyAmount")).getAttribute("value"));
			System.out.println("Message is: = " + driver.findElement(By.id("message")).getText());
			assertEquals(product_name, "Banana");
			assertEquals(driver.findElement(By.id("buyAmount")).getAttribute("value"), "0");
			assertEquals(driver.findElement(By.id("message")).getText(), "You can't buy 0 amount");	
			Thread.sleep(1000);
		} catch (Exception e) {
			e.printStackTrace();
		}
		
 }
 
 @Test(priority=4)																										//Negative test case with no product selected
 public void noProductSelected() {              
		
		try {
			Select products = new Select(driver.findElement(By.className("form-control")));
			buyProduct("Select",2);																						// buy function calling 	
			String defaultValue = products.getFirstSelectedOption().getText().toString();
			System.out.println("Default name = " + defaultValue);
			System.out.println("Amount selected = " + driver.findElement(By.id("buyAmount")).getAttribute("value"));
			System.out.println("Message is: = " + driver.findElement(By.id("message")).getText());
			assertEquals(defaultValue, "Select");
			assertEquals(driver.findElement(By.id("buyAmount")).getAttribute("value"), "2");
			assertEquals(driver.findElement(By.id("message")).getText(), "Please select a product!");	
			Thread.sleep(1000);
		} catch (Exception e) {
			e.printStackTrace();
		}
		
 }
		
 
 @Test(priority=5)																										//Negative test case with insufficient funds
 public void insufficientFunds() {              
		
		try {
			Select products = new Select(driver.findElement(By.className("form-control")));
			buyProduct(PRODUCT_NAME_TV,2);																						// buy function calling 	
			product_name = null;
			product_name = products.getFirstSelectedOption().getText().toString();
			System.out.println("Product selected = " + product_name);
			System.out.println("Amount selected = " + driver.findElement(By.id("buyAmount")).getAttribute("value"));
			System.out.println("Message is: = " + driver.findElement(By.id("message")).getText());
			assertEquals(product_name, "TV");
			assertEquals(driver.findElement(By.id("buyAmount")).getAttribute("value"), "2");
			assertEquals(driver.findElement(By.id("message")).getText(), "Insufficient funds!");	
			Thread.sleep(1000);
		} catch (Exception e) {
			e.printStackTrace();
		}
		
 }
 

 
 @AfterMethod
  public void exitBrowser() {
	 	driver.quit();
 }	
  		
	
}

